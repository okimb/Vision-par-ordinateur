#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 12 23:58:52 2019

@author: okimb
"""
"""
FLANN est l'abréviation de Fast NearLibrary_for_Approximate_Nearest_Neothers.
C'est un ensemble d'algorithmes pour les recherches par le plus proche voisin d'ensembles de données volumineux et de caractéristiques de grande dimension.
Et ces algorithmes ont été optimisés.
Cela fonctionne mieux face aux grands ensembles de données.
"""
import numpy as np
def test():

import cv2
from matplotlib import pyplot as plt

imge1 = cv2.imread('imageCrocod.jpg',0)          # queryImage
imge2 = cv2.imread('image_0006.jpg',0) # trainImage

# Initiate SIFT detector
#sift = cv2.SIFT()
sift = cv2.xfeatures2d.SIFT_create()
# find the keypoints and descriptors with SIFT
kp1, des1 = sift.detectAndCompute(imge1,None)
kp2, des2 = sift.detectAndCompute(imge2,None)

# FLANN parameters
FLANN_INDEX_KDTREE = 0
index_params = dict(algorithm = FLANN_INDEX_KDTREE, trees = 5)
search_params = dict(checks=100)   # or pass empty dictionary

flann = cv2.FlannBasedMatcher(index_params,search_params)

matches = flann.knnMatch(des1,des2,k=2)

# Need to draw only good matches, so create a mask
matchesMask = [[0,0] for i in range(len(matches))]

# ratio test as per Lowe's paper
for i,(m,n) in enumerate(matches):
    if m.distance < 0.7*n.distance:
        matchesMask[i]=[1,0]

draw_params = dict(matchColor = (0,255,0),
                   singlePointColor = (255,0,0),
                   matchesMask = matchesMask,
                   flags = 0)

imge3 = cv2.drawMatchesKnn(imge1,kp1,imge2,kp2,matches,None,**draw_params)
plt.imshow(imge3,),plt.show()