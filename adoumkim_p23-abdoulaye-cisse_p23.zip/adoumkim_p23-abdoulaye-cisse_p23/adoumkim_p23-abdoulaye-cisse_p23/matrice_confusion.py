import os
import numpy as np
import cv2
from statistics import mode
from collections import Counter

dataset1_path = 'dataset1/'
dossiers = os.listdir(dataset1_path)
sift = cv2.xfeatures2d.SIFT_create()
bf = cv2.BFMatcher()
classes = []
k_voisin = 5
desc = []
for dossier in dossiers:
    # print ('classe ',dossier)
    des_temp = []
    classes.append(dossier)
    # sdossiers=os.listdir(dataset1_path+dossier)
    for fichier in os.listdir(dataset1_path + dossier + '/train'):
        img1 = cv2.imread(dataset1_path + dossier + '/train/' + fichier)
        kp1, des1 = sift.detectAndCompute(img1, None)
        des_temp.append(des1)
    desc.append(des_temp)

print('les classes ', classes)
print(classes)

total = 0
correct = 0
trouve = []
confusion_matrice = []
for dossier in dossiers:
    ligne = np.zeros(len(classes))
    print('classe ', dossier)
    for fichier in os.listdir(dataset1_path + dossier + '/test'):
        img1 = cv2.imread(dataset1_path + dossier + '/test/' + fichier)
        kp1, des1 = sift.detectAndCompute(img1, None)
        trouve = []
        # boucle pour parcourir les lots
        for inde, obj in enumerate(desc):
            for des2 in obj:
                matches = bf.knnMatch(des1, des2, k=2)

                correspondance = 0
                for m, n in matches:
                    if m.distance < 1 * n.distance:
                        correspondance += 1
                trouve.append([classes[inde], correspondance])
        trouve_trie = sorted(trouve, key=lambda x: x[1], reverse=True)
        trouve_k_top = trouve_trie[:k_voisin]
        les_tops_classes = []
        for clas, corresp in trouve_k_top:
            les_tops_classes.append(clas)
        data = Counter(les_tops_classes)
        if data.most_common(1)[0][0] == dossier:
            print(dossier)
            correct += 1
        total += 1
        ligne[classes.index(data.most_common(1)[0][0])] += 1
        print("classe originale", dossier, 'classe predicte', data.most_common(1)[0][0])
        print(' taux de prediction : ', round((100 * correct / total), 2), ' %')

        # print(' les tops classes ',les_tops_classes, ' la mode ',data.most_common(1)[0][0])
        # print(' la classe originale est ',dossier, ' prediction est ',data.most_common(1)[0][0])
    confusion_matrice.append(ligne)
print(confusion_matrice)
# print('les classes ',classes)
print(' taux de prediction : ', round((100*correct/total),2),' %')
print('correct / total => ',correct,' / ', total)
for x in classes:
    print(x, end=' ')
print('\n')
for i, o in enumerate(confusion_matrice):
    for j, v in enumerate(o):
        if j == 0:
            print(classes[i], end=' ')
        print(int(v), end=' ')
    print('\n')

# print(trouve)

import seaborn as sn
import pandas as pd
import matplotlib.pyplot as plt

df_cm = pd.DataFrame(confusion_matrice, index=classes,
                     columns=classes)
plt.figure(figsize=(10, 7))
sn.heatmap(df_cm, annot=True)
plt.show()